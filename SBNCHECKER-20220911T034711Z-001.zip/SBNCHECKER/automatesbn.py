# importing import modules like os and sys
import os
import sys 
# we will get a directory of files present in folder like [1.txt,2.txt]
list_dir = "/home/soumya/iiitenv/MC2.0/sbnchecker/raw-sbn"
list1 = list(os.listdir(list_dir))
#sorting the list according to sequence like 0712 ,0715
list1 = sorted(list1)
# opening files for updation 
file2 = open('/home/soumya/iiitenv/MC2.0/sbnchecker/sbnmismatchdeeng', 'r+')
file2.truncate(0)
file = open('/home/soumya/iiitenv/MC2.0/sbnchecker/sbn_test/sbnfileall', 'r+')
file.truncate(0)
file1 = open('/home/soumya/iiitenv/MC2.0/sbnchecker/german_sent', 'r+')
file1.truncate(0)

# loop over the list of files 
for i in list1:
     f = open('/home/soumya/iiitenv/MC2.0/sbnchecker/raw-sbn/%s'%i,'r')
     
     # a reads raw-sbn
     a = f.read()
     # b is raw format
     b = a[:a.index("%")]
     # c is sbn format
     c = a[a.index("%"):]
     
     # d is the file name we have obtaineed
      
     d = c[c.index('input')+6: c.index('de.parse')]
     e = d.split('/')
     # folder name 
     # f1 is file name whereas p2 is folder anme 
     f1 = e[1]
     p2 = e[2]
     # opening the german sbn file according to folder/file
     d1 = open('/home/soumya/iiitenv/MC2.0/sbnchecker/pmb-4.0.0-de-gold/{}/{}/de.drs.sbn'.format(f1,p2),'r')
     d1 = d1.read()
     d1  = d1[d1.index('de.drs.sbn')+3:]
     dp = d1.split('\n')
     dp = sorted(dp)
     
     #print(dp)
     # for the left hand side comparision 
     finald = ''
     for j in range(0,len(dp)):
     
         if '.0' in dp[j] and '%' in dp[j]:
             finald = finald  + "  " + dp[j][:dp[j].index('.0')-2]
             finald = finald.rstrip()
     finaldf = ''
     finaldf = finaldf + finald
      
     #print(finaldf)
         
         
      # used exception handling for the file if there is no english sbn files   
     try:     
         e1 = open('/home/soumya/iiitenv/MC2.0/sbnchecker/pmb-4.0.0-en-gold/{}/{}/en.drs.sbn'.format(f1,p2),'r+')
     except Exception :
         file2.write('there is no english sbn file for  {} , {} \n'.format(f1,p2))
         continue 
         
     # same as above but now for english sbn files    
     e1 = e1.read()
     e1  = e1[e1.index('en.drs.sbn')+3:]
     ep = e1.split('\n')
     ep = sorted(ep)
     finale = ''
     for k in range(0,len(ep)):
         
         if '.0'   in ep[k] and '%' in ep[k] :
             finale = finale   + "  " +  ep[k][:ep[k].index('.0')-2]
             finale = finale.rstrip()
     #print(finale)
             
             
             
     finalef = ''
     finalef = finalef + finale
     #print(str(finale)) 
     # comparing both sbn files 
     if finalef == finaldf :
         #print("true") 
         #if it is same then it will run 
         file.write("{} \n".format(c) )
         
         file1.write("{} \n".format(b) )
     else:
         # else it will be inputed into sbn error file
         #print("mismatchsbn ")  
         
         
         
         file2.write('error at sbn file {} , {} \n'.format(f1,p2)) 
     
    
             
         
           
             
             
             
         
     
    
