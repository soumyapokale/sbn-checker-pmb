python3 automatesbn.py
